import pandas as pd
from fpdf import FPDF
import datetime

# --- SYSTEM INITIALIZATION ---
def load_system():
    try:
        icd_db = pd.read_csv('icd11_dataset.csv')
        sol_db = pd.read_csv('solutions.csv')
        return icd_db, sol_db
    except:
        print("Error: Ensure CSV files are in the folder.")
        return None, None

def generate_medical_pdf(report_text, code, severity_lvl):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(200, 10, "ICD-11 Clinical Consultation Summary", ln=True, align='C')
    pdf.ln(10)
    
    # Add URGENY tag if severity is high
    if severity_lvl >= 8:
        pdf.set_text_color(255, 0, 0) # Red Text
        pdf.cell(200, 10, "STATUS: URGENT / HIGH SEVERITY", ln=True, align='L')
        pdf.set_text_color(0, 0, 0) # Back to Black
    
    pdf.set_font("Arial", size=11)
    pdf.multi_cell(0, 10, report_text)
    filename = f"Medical_Report_{code}_{datetime.date.today()}.pdf"
    pdf.output(filename)
    print(f"\n[Success] Professional Report saved as {filename}")

# --- THE ADVANCED AI ENGINE ---
def run_naresh_ai():
    icd_db, sol_db = load_system()
    if icd_db is None: return

    print("--- Naresh Medical AI: Advanced Diagnostic Mode ---")
    
    while True:
        # STEP 1: INITIAL QUESTION
        print("\nAI: Please describe your symptoms (or type 'exit')")
        user_input = input("You: ").lower()
        if user_input == 'exit': break

        # STEP 2: CLARIFICATION LOGIC
        matches = icd_db[icd_db['Disease / Condition Title'].str.contains(user_input, case=False, na=False)]

        if len(matches) > 1:
            print(f"AI: I found {len(matches)} specific types. Is it more like: {', '.join(matches['Disease / Condition Title'].values[:3])}?")
            detail = input("You: ").lower()
            matches = matches[matches['Disease / Condition Title'].str.contains(detail, case=False, na=False)]

        if not matches.empty:
            result = matches.iloc[0]
            code = result['ICD-11 Code']
            
            # STEP 3: SEVERITY SCALE (The 1-10 Logic)
            print("AI: On a scale of 1 (very mild) to 10 (emergency), how severe is the pain/issue?")
            try:
                pain_lvl = int(input("You (1-10): "))
            except:
                pain_lvl = 1

            # Map to ICD-11 Extension Codes (from your Word docs)
            ext_code = "XS5W (Mild)" if pain_lvl <= 3 else "XS0T (Moderate)" if pain_lvl <= 7 else "XS25 (Severe)"
            
            # STEP 4: SOLUTION LOOKUP
            treatment_row = sol_db[sol_db['ICD-11 Code'] == code]
            treatment = treatment_row.iloc[0]['Treatment'] if not treatment_row.empty else "No specific first-aid found."

            report_content = f"""
Date: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}
Condition: {result['Disease / Condition Title']}
ICD-11 Code: {code}
System Chapter: {result['Chapter / System']}
---------------------------------------------------
CLINICAL SEVERITY: {pain_lvl}/10
ICD-11 EXTENSION: {ext_code}
---------------------------------------------------
RECOMMENDED CARE & SOLUTION:
{treatment}

Disclaimer: For professional use only. In case of emergency, dial 911 immediately.
"""
            print("\n" + report_content)
            
            # STEP 5: PDF EXPORT
            if input("Would you like to export this for your doctor? (yes/no): ").lower() == 'yes':
                generate_medical_pdf(report_content, code, pain_lvl)

        else:
            print("AI: I couldn't match that to an ICD-11 code. Please be more specific about the body part.")

if __name__ == "__main__":
    run_naresh_ai()