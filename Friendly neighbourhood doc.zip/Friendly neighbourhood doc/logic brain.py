import pandas as pd

# Load your custom ICD-11 Dataset
df = pd.read_csv('icd11_dataset.csv')

# 1. THE SOLUTION DATABASE (The "Treatment" Brain)
# You can expand this as you learn more medical first-aid
treatment_map = {
    "8A80.0": "Migraine: Rest in a dark, quiet room. Stay hydrated. Apply a cool cloth to the forehead.",
    "ED80": "Acne: Cleanse gently twice a day. Use non-comedogenic products. Avoid touching the face.",
    "ME00": "Bloating: Small frequent meals. Avoid carbonated drinks. Gentle walking to aid digestion.",
    "NB90.3": "Skin Scrape: Clean with mild soap and water. Apply antiseptic and a sterile bandage.",
    "MA01.1": "Facial Pain: Use warm compresses. Practice jaw relaxation. See a dentist if it persists."
}

# 2. BODY PART MAPPER
# Maps common body parts to ICD-11 Clinical Categories
body_part_map = {
    "head": "Nervous System",
    "stomach": "Digestive System",
    "skin": "Skin diseases",
    "face": "Visual system or Skin",
    "arm": "Musculoskeletal",
    "leg": "Musculoskeletal"
}

def resolve_issue(voice_input):
    text = voice_input.lower()
    
    # NEGATIVE LEARNING: Ignore if the user says "No" or "Don't have"
    if "don't have" in text or "no pain" in text:
        return "Noted. I will exclude that from the diagnosis."

    # SEARCH LOGIC
    found_row = None
    detected_part = next((part for part in body_part_map if part in text), "General")

    for _, row in df.iterrows():
        if str(row['Disease / Condition Title']).lower() in text:
            found_row = row
            break
    
    if found_row is not None:
        code = found_row['ICD-11 Code']
        title = found_row['Disease / Condition Title']
        solution = treatment_map.get(code, "Consult a specialist for a specific clinical treatment.")
        
        return f"""
        [NARESH PROJECT DIAGNOSIS]
        -------------------------------------------
        Body Part: {detected_part.upper()}
        Detected Issue: {title}
        ICD-11 Code: {code}
        
        TREATMENT/SOLUTION:
        {solution}
        -------------------------------------------
        """
    return "Issue not recognized. Please describe the sensation (e.g., 'sharp pain' or 'rash')."

# Example: If you speak: "I have a sharp Migraine without aura in my head"
print(resolve_issue("I have a Migraine without aura in my head"))